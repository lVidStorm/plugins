package net.runelite.client.plugins.microbot.storm.modified.slayer.enums;

public enum State {
    GET_TASK,
    RESTOCK,
    TRAVEL_TO_MONSTER,
    FIGHT_MONSTER,
    SPECIAL_TRANSPORT,
    RESET,
    IDLE
}
